<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medalla extends Model
{
    protected $table = 'medalla';
    protected $fillable = ['pais_id', 'tipo'];

    public function pais()
    {
        return $this->belongsTo(Pais::class);
    }
}
