<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Medalla;
use Illuminate\Http\Request;

class MedallaController extends Controller
{
    public function index()
    {
        return Medalla::with('pais')->get();
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'pais_id' => 'required|exists:pais,id',
            'tipo' => 'required|in:oro,plata,bronce'
        ]);

        return Medalla::create($validated);
    }

    public function show($id)
    {
        return Medalla::with('pais')->findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $medalla = Medalla::findOrFail($id);
        $medalla->update($request->all());
        return $medalla;
    }

    public function destroy($id)
    {
        $medalla = Medalla::findOrFail($id);
        $medalla->delete();
        return response()->json(['message' => 'Medalla eliminada']);
    }
}
